The project implements a calculator supporting

 - Addition
 - Subtraction
 - Multiplication
 - Integer divison
 
 for negative and positive integers
 
 Controls:
  0-9: Add a digit to the screen
  A: Select add operation
  B: Select minus operation
  C: Select division operation
  D: Select multiplication operation
  *: Clear row / reset program (if second operand is empty)
  #: run operation
  
 Notes:
  The calculator does support negtive numbers but there is no negate button as I ran out buttons
  However you can negate by setting the first operator as 0 and subtracting a number to test the functionality
  
  To run the project load ex9/calculator.kmd or compile and load ex9/calculator.s
  A concatenated source file is found at concatenated_source/calculator.s
